import numpy as np
import matplotlib.pyplot as plt
import os, argparse, math, random
from datetime import datetime
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture as gm
import errno

''' 
	Select k distinct random vectors from the features dataset for each (class(combining all images data))
	Now, for each image we want to have a k(32) dimensional bag of visual words
'''
start_time = datetime.now()
ap = argparse.ArgumentParser()
ap.add_argument("-s", "--source", required=True, help="Raw data set location")
ap.add_argument("-o", "--output", required=True, help="Output mean location")
ap.add_argument("-c", "--clusters",required=True,help="No of clusters")
args = vars(ap.parse_args())

numOfClusters = int(args["clusters"])

cntForFile = 0
wholeData = []
lengthOfFile = []

clusterSize = np.zeros((numOfClusters))
print("Starting up")

#handling of files
def fileHandle(fileName):
	file = open(fileName)
	for line in file:
		teLine = line.rstrip('\n ').split(' ')
		nLine = [float(i) for i in teLine]
		nLine = np.array(nLine)
		wholeData.append(nLine)

	file.close()
	return

#euclidean distance calculation
def euclidDist(centroid, dataPt):
	ldist = centroid-dataPt
	return np.sum(np.transpose(ldist)*ldist)

#calculating distance matrix for a point
def distArray(dataPt):
	distVector = np.zeros((numOfClusters), dtype=np.float64)
	for ind in range(numOfClusters):
		distVector[ind] = euclidDist(meanVector[ind], dataPt)
	return distVector

#assignment of clusters
def assignDataPt():
	costFunc = 0.0
	cnt = 0
	for dataPt in wholeData:
		distVector = distArray(dataPt)
		noCl = np.argmin(distVector)	
		pointsAssignCluster[cnt] = noCl
		# print("\n noCl = ", noCl, "\ncluster = ", clusters[noCl], "\n")
		clusters[noCl] += dataPt
		# print("data = ", dataPt)
		# print("\n noCl = ", noCl, "\ncluster = ", clusters[noCl], "\n")
		clusterSize[noCl] += 1
		costFunc += distVector[noCl]
		cnt += 1
	return costFunc

def reCalcMean():
	for i in range(numOfClusters):
		# print("Cluster Size[i]: ",clusterSize[i])
		# if(clusterSize[i]==0):
		# 	print("Reinitializing mean :( ")
		# 	initMean()
		# 	return
		meanVector[i] = clusters[i]/clusterSize[i]
		clusters[i] = 0
		clusterSize[i] = 0



def plotHistogram(values, bins, type, name):
    graphName = "Bag of Visual Words representation for "+name

    plt.hist(values, bins, facecolor='green')
    plt.xlabel("Visual Words")
    plt.ylabel("Number of patches")
    plt.title(graphName)
    plt.show()


def likelihoodPlotter(values, graphName, title):
    y = range(1,len(values)+1)
    plt.plot(values, y)
    plt.xlabel("No. of")
    plt.ylabel("")
    plt.title(title)
    plt.savefig(graphName+".jpg")
    


def plotClustersAndMean(outputPath, wholeData, numOfClusters, pointsAssignCluster, meanVector, plotName="My beautiful  Cat",flag=False):
    xFeature = []
    yFeature = []
    colors = ['#136906', '#fcbdfc', '#e5ff00', '#ff0000', '#3700ff', '#000000']
    plt.xlabel('Mean')
    plt.ylabel('Dispersion')

    class_colours = ['blue', 'red', 'green']
    class_colours1 = ['blue', 'yellow', 'green']
    classes = ["Cluster1", "Cluster2", "Cluster3"]

    recs = []
    for i in range(0, len(class_colours)):
        recs.append(mpatches.Rectangle((0, 0), 1, 1, fc=class_colours[i]))
    plt.legend(recs, classes, loc='upper right')

    print("Grapher:")
    # print("No of points: ",len(wholeData))
    # print("no of clusters: ", numOfClusters)
    # print("points assigned1: ", len(pointsAssignCluster))
    # print("mean vector: ", meanVector)
    plt.ion()
    # if flag:
    #     plt.figure()

    for i in range(numOfClusters):
        xFeature.append([])
        yFeature.append([])
    # plt.figure()
    for i in range(len(wholeData)):
        # print("index val: ", int(pointsAssignCluster[i]), " : size: ",len(xFeature))
        xFeature[int(pointsAssignCluster[i])].append(wholeData[i, 0])
        yFeature[int(pointsAssignCluster[i])].append(wholeData[i, 1])

    for k in range(numOfClusters):
        plt.scatter(xFeature[k], yFeature[k], marker='.', s=1, c=class_colours[k])
        plt.scatter([meanVector[k, 0]], [meanVector[k, 1]], marker='*', c=class_colours1[3-k-1])
        plt.title(plotName)
    plt.draw()
    plt.savefig(outputPath+".jpg")
    plt.pause(0.5)
    plt.clf()
    return


print("Process start")
for root, dirs, files in os.walk(args["source"]):
	for f in files:
		path = os.path.relpath(os.path.join(root, f), ".")
		# print("read: ",path)
		fileHandle(path)
		lengthOfFile.append(len(wholeData)-cntForFile)
		cntForFile = len(wholeData)

wholeData = np.array(wholeData)
meanVector = []
clusters = np.zeros((numOfClusters, np.size(wholeData, axis=1)),dtype=np.float64)

def initMean():
	global meanVector
	meanVector = []
	temp = random.sample(range(len(wholeData)-1), numOfClusters)
	for assign in temp:
		meanVector.append(wholeData[assign])
	meanVector = np.array(meanVector, dtype=np.float64)

	
#Now, k-means clustering
J = 0.0					#present Cost function
Jprev = -1.0			#previous Cost function
threshold = 1e-3



initMean()
pointsAssignCluster = np.zeros((np.size(wholeData,axis=0)))
# # print(wholeData)
loopStarttime = datetime.now()
counter = 0
while True:
	a = datetime.now()
	J = assignDataPt()
	print(counter," : J: ", J, "\t : ",(Jprev-J)," : ",(datetime.now()-loopStarttime))
	# meanVector, " : ", 
	# print(counter, " : Cost = ", (Jprev-J))
	counter += 1
	if len(wholeData[0]) < 3:
		plotClustersAndMean(args['output']+str(counter)+"_",wholeData, numOfClusters, pointsAssignCluster, meanVector,"K-Means")
	if Jprev != -1 and Jprev - J < threshold:
		reCalcMean()
		break
	Jprev = J
	reCalcMean()
	b = datetime.now()
	# print(b-a)


lengthOfFile = np.array(lengthOfFile)
BOVW = np.zeros((len(lengthOfFile), numOfClusters))

cnt = 0
for i, lenFile in enumerate(lengthOfFile):
	for ind in range(lenFile):
	 	j = pointsAssignCluster[cnt + ind]
	 	BOVW[i, int(j)] += 1 
	cnt += lenFile

print("Bag of visual words")
if numOfClusters> 0:
	print(BOVW)
	targetPath = args['output']+str(numOfClusters)+".BOW"
	if not os.path.exists(os.path.dirname(args['output'])):
			try:
				os.makedirs(os.path.dirname(args['output']))
			except OSError as exc:  # Guard against race condition
				if exc.errno != errno.EEXIST:
					raise
	try:
		print("target File: ", targetPath)
		outfile = open(targetPath, "w")
	except IOError:
		print("File not created !!!!!!!!!!!!!!!!!!!!!!!!!")

	for bag in BOVW:
		for a in bag:
			outfile.write(str(a)+" ")
		outfile.write("\n")
	outfile.close()
# print("Final mean Vector = ", meanVector)

targetPath = args['output']+".kmeans"
if not os.path.exists(os.path.dirname(args['output'])):
        try:
            os.makedirs(os.path.dirname(args['output']))
        except OSError as exc:  # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise
try:
	print("target File: ", targetPath)
	outfile = open(targetPath, "w")
except IOError:
	print("File not created !!!!!!!!!!!!!!!!!!!!!!!!!")

for mean in meanVector:
	for feature in mean:
		outfile.write(str(feature)+" ")
	outfile.write("\n")
outfile.close()


