import numpy as np
import sys
import matplotlib.pyplot as plt
import os
import errno
import argparse
import math
import random
from datetime import datetime


ap = argparse.ArgumentParser()
ap.add_argument("-s", "--source", required=True, help="Raw data set location")
ap.add_argument("-b", "--bow", required=True, help="Raw BoVW data set location")
ap.add_argument("-o", "--output", required=True, help="output location")
args = vars(ap.parse_args())

def plotHistogram(values, bins, title, name):
    graphName = "Bag of Visual Words representation"
    # print("making graph: ")
    name = name+".jpg"
    plt.hist(values, bins, facecolor='green', rwidth=0.8)
    # print("histogram made: ")
    plt.xlabel("Visual Words (Clusters)")
    plt.ylabel("Number of patches")
    plt.title(graphName)
    # plt.show()
    print("plot path: ",name)
    if not os.path.exists(os.path.dirname(name)):
        try:
            os.makedirs(os.path.dirname(name))
        except OSError as exc:  # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise
    plt.savefig(name)

def fileHandle(folder):
    wholeData = []
    for file_name in os.listdir(folder):
        if file_name.endswith(".txt"):
            file_path = os.path.join(folder, file_name)
            with open(file_path, 'r') as file:
                for line in file:
                    teLine = line.rstrip('\n ').split(' ')
                    nLine = [int(float(i)) for i in teLine]
                    nLine = np.array(nLine)
                    wholeData.append(nLine)
    return wholeData

i = 0
wholeData = fileHandle(args['bow'])
# print(wholeData)
fileCount = len(wholeData)
xvalues = range(1,33)

for root, dirs, files in os.walk(args["source"]):
    for f in files:
        path = os.path.relpath(os.path.join(root, f), ".")
        target = os.path.splitext(f)[0]
        print("Target:", target)

        if i < len(wholeData):
            plotHistogram(wholeData[i], xvalues, os.path.join(args['output'], target), target)
        else:
            print("Error: Index out of range")
        
        i += 1


